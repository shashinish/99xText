//
//  ViewController.swift
//  GBSENNX
//
//  Created by Shashi Nishantha on 2/11/21.
//

import UIKit
import ReSwift
import SDWebImage
import JGProgressHUD
import CRNotifications

class BookListViewController: UIViewController, UISearchBarDelegate, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    
    var booksArray:[Book] = []
    var progressHud:JGProgressHUD?
    var selectedVoilueID:String = ""
    
    var maxResult:Int = 20
    var startIndex:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        searchBar.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableFooterView = UIView.init()
        
        fetchBooks()
    }
    
    @objc func searchBooks(){
        startIndex = 0
        booksArray.removeAll()
        tableView.reloadData()
        fetchBooks()
    }
    
    
    func fetchBooks(){
        
        if searchBar.text!.isEmpty {
            return
        }
        
        let srchText = searchBar.text!
        
        showHud()
        Api.sharedInstance.searchBooks(queryParam: srchText, maxResult: maxResult, startIndex: startIndex, success: { (bookResponseArray) in
            self.booksArray.append(contentsOf: bookResponseArray)
            self.dismissHud()
            self.tableView.reloadData()
        }) { (error) in
            self.dismissHud()
            CRNotifications.showNotification(type: CRNotifications.error, title: "Error!", message: "Error fetching data from book server", dismissDelay: 2)
        }
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(searchBooks), object: nil)
        self.perform(#selector(searchBooks), with: nil, afterDelay: 0.5)
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        self.searchBar.showsCancelButton = true
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.showsCancelButton = false
        self.searchBar.text = ""
        self.searchBar.resignFirstResponder()
        self.booksArray.removeAll()
        self.tableView.reloadData()
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 122
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return booksArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:BookTableViewCell = tableView.dequeueReusableCell(withIdentifier: "BookTableCell", for: indexPath) as! BookTableViewCell
        let bookObj:Book = self.booksArray[indexPath.row]
    
        if let imgLinks = bookObj.volumeInfo?.imageLinks {
            if let imgUrl = URL.init(string: imgLinks.smallThumbnail) {
                cell.imgBook.sd_setImage(with: imgUrl) { (image, error, cache, url) in
                    cell.imgBook.image = image
                }
            }
        }
        
        cell.lblBookTitle.text = bookObj.volumeInfo.title
        cell.lblBookAuthor.text = self.getAuthorAtring(authors: bookObj.volumeInfo.authors)
        cell.lblBookDescp.text = bookObj.volumeInfo.contentVersion
        cell.selectionStyle = .none
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let bookObj:Book = self.booksArray[indexPath.row]
        selectedVoilueID = bookObj.id
        performSegue(withIdentifier: "showBook", sender: self)
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {

        // UITableView only moves in one direction, y axis
        let currentOffset = scrollView.contentOffset.y
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height

        // Change 10.0 to adjust the distance from bottom
        if maximumOffset - currentOffset <= 10.0 {
            startIndex += maxResult
            fetchBooks()
        }
    }

    
    func showHud(){
        progressHud = JGProgressHUD(style: .dark)
        progressHud!.textLabel.text = "Loading"
        progressHud!.show(in: self.view)
    }
    
    func dismissHud(){
        progressHud?.dismiss()
    }
    
    func getAuthorAtring(authors: [String]) -> String{
        var aList:String = "Not Mentioned"
        if authors.count > 0 {
            aList = ""
            for author in authors {
                aList = "\(aList) \(author)"
            }
        }
        return aList.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showBook" {
            let viewController = segue.destination as? BookDetailViewController
            viewController?.volumeID = selectedVoilueID
        }
    }

}


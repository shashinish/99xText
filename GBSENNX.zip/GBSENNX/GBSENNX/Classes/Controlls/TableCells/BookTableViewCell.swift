//
//  BookTableViewCell.swift
//  GBSENNX
//
//  Created by Shashi Nishantha on 2/11/21.
//

import UIKit

class BookTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imgBook: UIImageView!
    @IBOutlet weak var lblBookTitle: UILabel!
    @IBOutlet weak var lblBookAuthor: UILabel!
    @IBOutlet weak var lblBookDescp: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        imgBook.layer.borderColor = UIColor.init(red: 236.0/255.0, green: 236.0/255.0, blue: 236.0/255.0, alpha: 1.0).cgColor
        imgBook.layer.borderWidth = 0.5
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

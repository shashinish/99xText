//
//  BookDetailViewController.swift
//  GBSENNX
//
//  Created by Shashi Nishantha on 2/11/21.
//

import UIKit
import ReSwift
import SDWebImage
import JGProgressHUD
import CRNotifications

class BookDetailViewController: UIViewController {
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblAuthor: UILabel!
    @IBOutlet weak var imgBook: UIImageView!
    @IBOutlet weak var lblDescp: UILabel!
    
    
    var progressHud:JGProgressHUD?
    var volumeID:String?
    var bookObject:Book?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        fetchBookData()
    }
    
    func fetchBookData(){
        showHud()
        Api.sharedInstance.fetchBookByID(volumeId: volumeID!, success: { (book) in
            self.dismissHud()
            self.bookObject = book
            self.updateUI()
            
        }) { (error) in
            self.dismissHud()
            CRNotifications.showNotification(type: CRNotifications.error, title: "Error!", message: "Error fetching data from book server", dismissDelay: 2)
        }
    }
    
    func updateUI(){
        self.lblTitle.text = bookObject?.volumeInfo.title
        self.lblAuthor.text = self.getAuthorAtring(authors: bookObject?.volumeInfo.authors ?? [])
        if let imgLinks = bookObject?.volumeInfo?.imageLinks {
            if let imgUrl = URL.init(string: imgLinks.smallThumbnail) {
                imgBook.sd_setImage(with: imgUrl) { (image, error, cache, url) in
                    self.imgBook.image = image
                }
            }
        }
        
        let data = bookObject?.volumeInfo.descriptionField.data(using: .utf8)! ?? Data.init()
        let attributedString = try? NSAttributedString(
        data: data,
        options: [.documentType: NSAttributedString.DocumentType.html],
        documentAttributes: nil)
        lblDescp.attributedText = attributedString
    }
    
    func showHud(){
        progressHud = JGProgressHUD(style: .dark)
        progressHud!.textLabel.text = "Loading"
        progressHud!.show(in: self.view)
    }
    
    func dismissHud(){
        progressHud?.dismiss()
    }
    
    func getAuthorAtring(authors: [String]) -> String{
        var aList:String = "Not Mentioned"
        if authors.count > 0 {
            aList = ""
            for author in authors {
                aList = "\(aList) \(author)"
            }
        }
        return aList.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

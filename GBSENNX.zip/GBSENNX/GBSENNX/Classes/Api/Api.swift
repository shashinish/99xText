//
//  Api.swift
//  GBSENNX
//
//  Created by Shashi Nishantha on 2/11/21.
//

import Foundation
import UIKit
import Alamofire
import SwiftyJSON

typealias SuccessClosure = (_ books: [Book]) -> Void
typealias SingleBookSuccessClosure = (_ book: Book) -> Void
typealias NetworkError = (_ error: Error?) -> Void
typealias ServicesError = (_ error: ServiceError?) -> Void


class Api: NSObject {
    
    private static var _api = Api()
    var sessionManager: SessionManager
    
    class var sharedInstance: Api {
        return _api
    }
    
    deinit {
        
    }
    
    
    override init() {
        var defaultHeaders = Alamofire.SessionManager.defaultHTTPHeaders
        
        defaultHeaders[Constants.HeaderKeys.Accept] = Constants.APIKeys.ContentType
        defaultHeaders[Constants.HeaderKeys.ContentType] = Constants.APIKeys.ContentType
        
        let configuration = URLSessionConfiguration.default
        configuration.httpAdditionalHeaders = defaultHeaders
        
        self.sessionManager = SessionManager(configuration: configuration)
        super.init()
    }
    
    // USAGE:  Search Books
    func searchBooks(queryParam: String,maxResult: Int,startIndex: Int,success: @escaping SuccessClosure, failed: @escaping ServicesError) {
        
        
        var URL = Constants.API_BASE_RESOURCE
        URL = "\(URL)?q=\(queryParam)&maxResults=\(maxResult)&startIndex=\(startIndex)"
        self.sessionManager.request(URL, method: .get, parameters: nil, encoding: JSONEncoding.default).responseAPI { (response) in
            
            if response.response == nil {
                failed(ServiceError.init(code: 500, message: "Server Error"))
            }else if response.error != nil {
                failed(ServiceError.init(code: 500, message: "Server Error"))
            } else {
                if response.response?.statusCode == 200 {
                    let json:JSON = self.ParseJSON(data: response.data!)!
                    print(json)
                    
                    let jsonItems = json["items"].array ?? []
                    var booksArray:[Book] = []
                    for item in jsonItems {
                        booksArray.append(Book.init(fromJson: item))
                    }

                    success(booksArray)
                }else{
                    if response.response?.statusCode == 401 {
                        let json:JSON = self.ParseJSON(data: response.data!)!
                        let error_json = json["errors"]
                        let error = ServiceError.init(fromJson: error_json)
                        failed(error)
                    }else{
                        failed(ServiceError.init(code: 500, message: "Server Error"))
                    }
                }
            }
        }
    }
    
    func fetchBookByID(volumeId: String,success: @escaping SingleBookSuccessClosure, failed: @escaping ServicesError) {
        
        var URL = Constants.API_BASE_RESOURCE
        URL = "\(URL)/\(volumeId)"
        self.sessionManager.request(URL, method: .get, parameters: nil, encoding: JSONEncoding.default).responseAPI { (response) in
            
            if response.response == nil {
                failed(ServiceError.init(code: 500, message: "Server Error"))
            }else if response.error != nil {
                failed(ServiceError.init(code: 500, message: "Server Error"))
            } else {
                if response.response?.statusCode == 200 {
                    let json:JSON = self.ParseJSON(data: response.data!)!
                    print(json)
                    let bookObj = Book.init(fromJson: json)
                    success(bookObj)
                }else{
                    if response.response?.statusCode == 401 {
                        let json:JSON = self.ParseJSON(data: response.data!)!
                        let error_json = json["errors"]
                        let error = ServiceError.init(fromJson: error_json)
                        failed(error)
                    }else{
                        failed(ServiceError.init(code: 500, message: "Server Error"))
                    }
                }
            }
        }
    }
    
    func ParseJSON(data:Data?) -> JSON? {
        do {
            let json = try JSON(data: data!)
            return json
        } catch _ as NSError {
            // error
            return nil
        }
    }
    
}



extension DataRequest {
    @discardableResult
    func responseAPI(queue: DispatchQueue? = nil, completionHandler: @escaping (DefaultDataResponse) -> Void) -> Self {
        
        return response(completionHandler: { (response) in
            print("Request: \(String(describing: response.request))")
            print("Response: \(String(describing: response.response))")
            print("Error: \(String(describing: response.error))")
            if response.error != nil {
                if response.error?._code == -1004 {
                    print("Could not connect to the server.")
                }
                if response.error?._code == -1009 {
                    print("The Internet connection appears to be offline.")
                }
                completionHandler(response)
                return
            }
            
            if response.response?.statusCode == 500 {
                print("The Server Error. We will fix this soon")
            }
            
            completionHandler(response)
            
        })
    }
}


//
//  Constants.swift
//  GBSENNX
//
//  Created by Shashi Nishantha on 2/11/21.
//

import Foundation

class Constants: NSObject {
    
    // Api Base URL
    static let API_BASE_RESOURCE = "https://www.googleapis.com/books/v1/volumes"
    
    // Api Header keys
    struct HeaderKeys {
        static let Accept = "Accept"
        static let ContentType = "Content-Type"
    }
    
    // Api key vaalus
    struct APIKeys {
        static let ContentType = "application/json"
        static let Accept = "application/json"
    }
    
    
}

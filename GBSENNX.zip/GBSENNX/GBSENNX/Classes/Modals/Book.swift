//
//  Book.swift
//  GBSENNX
//
//  Created by Shashi Nishantha on 2/11/21.
//

import Foundation
import SwiftyJSON


class Book : NSObject, NSCoding{

    var etag : String!
    var id : String!
    var selfLink : String!
    var volumeInfo : VolumeInfo!

    /**
     * Instantiate the instance using the passed json values to set the properties values
     */
    init(fromJson json: JSON!){
        if json.isEmpty{
            return
        }
        etag = json["etag"].stringValue
        id = json["id"].stringValue
        selfLink = json["selfLink"].stringValue
        let volumeInfoJson = json["volumeInfo"]
        if !volumeInfoJson.isEmpty{
            volumeInfo = VolumeInfo(fromJson: volumeInfoJson)
        }
    }

    /**
     * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
     */
    func toDictionary() -> [String:Any]
    {
        var dictionary = [String:Any]()
        if etag != nil{
            dictionary["etag"] = etag
        }
        if id != nil{
            dictionary["id"] = id
        }
        if selfLink != nil{
            dictionary["selfLink"] = selfLink
        }
        if volumeInfo != nil{
            dictionary["volumeInfo"] = volumeInfo.toDictionary()
        }
        return dictionary
    }

    /**
    * NSCoding required initializer.
    * Fills the data from the passed decoder
    */
    @objc required init(coder aDecoder: NSCoder)
    {
        etag = aDecoder.decodeObject(forKey: "etag") as? String
        id = aDecoder.decodeObject(forKey: "id") as? String
        selfLink = aDecoder.decodeObject(forKey: "selfLink") as? String
        volumeInfo = aDecoder.decodeObject(forKey: "volumeInfo") as? VolumeInfo
    }

    /**
    * NSCoding required method.
    * Encodes mode properties into the decoder
    */
    func encode(with aCoder: NSCoder)
    {
        if etag != nil{
            aCoder.encode(etag, forKey: "etag")
        }
        if id != nil{
            aCoder.encode(id, forKey: "id")
        }
        if selfLink != nil{
            aCoder.encode(selfLink, forKey: "selfLink")
        }
        if volumeInfo != nil{
            aCoder.encode(volumeInfo, forKey: "volumeInfo")
        }

    }

}

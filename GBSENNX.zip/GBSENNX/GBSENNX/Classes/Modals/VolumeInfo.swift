//
//  VolumeInfo.swift
//  GBSENNX
//
//  Created by Shashi Nishantha on 2/11/21.
//


import Foundation
import SwiftyJSON



class VolumeInfo : NSObject, NSCoding{

    var authors : [String]!
    var contentVersion : String!
    var descriptionField : String!
    var imageLinks : ImageLink!
    var language : String!
    var printType : String!
    var publishedDate : String!
    var publisher : String!
    var title : String!

    /**
     * Instantiate the instance using the passed json values to set the properties values
     */
    init(fromJson json: JSON!){
        if json.isEmpty{
            return
        }
        authors = [String]()
        let authorsArray = json["authors"].arrayValue
        for authorsJson in authorsArray{
            authors.append(authorsJson.stringValue)
        }
        contentVersion = json["contentVersion"].stringValue
        descriptionField = json["description"].stringValue
        let imageLinksJson = json["imageLinks"]
        if !imageLinksJson.isEmpty{
            imageLinks = ImageLink(fromJson: imageLinksJson)
        }
        language = json["language"].stringValue
        printType = json["printType"].stringValue
        publishedDate = json["publishedDate"].stringValue
        publisher = json["publisher"].stringValue
        title = json["title"].stringValue
    }

    /**
     * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
     */
    func toDictionary() -> [String:Any]
    {
        var dictionary = [String:Any]()
        if authors != nil{
            dictionary["authors"] = authors
        }
        if contentVersion != nil{
            dictionary["contentVersion"] = contentVersion
        }
        if descriptionField != nil{
            dictionary["description"] = descriptionField
        }
        if imageLinks != nil{
            dictionary["imageLinks"] = imageLinks.toDictionary()
        }
        if language != nil{
            dictionary["language"] = language
        }
        if printType != nil{
            dictionary["printType"] = printType
        }
        if publishedDate != nil{
            dictionary["publishedDate"] = publishedDate
        }
        if publisher != nil{
            dictionary["publisher"] = publisher
        }
        if title != nil{
            dictionary["title"] = title
        }
        return dictionary
    }

    /**
    * NSCoding required initializer.
    * Fills the data from the passed decoder
    */
    @objc required init(coder aDecoder: NSCoder)
    {
        authors = aDecoder.decodeObject(forKey: "authors") as? [String]
        contentVersion = aDecoder.decodeObject(forKey: "contentVersion") as? String
        descriptionField = aDecoder.decodeObject(forKey: "description") as? String
        imageLinks = aDecoder.decodeObject(forKey: "imageLinks") as? ImageLink
        language = aDecoder.decodeObject(forKey: "language") as? String
        printType = aDecoder.decodeObject(forKey: "printType") as? String
        publishedDate = aDecoder.decodeObject(forKey: "publishedDate") as? String
        publisher = aDecoder.decodeObject(forKey: "publisher") as? String
        title = aDecoder.decodeObject(forKey: "title") as? String
    }

    /**
    * NSCoding required method.
    * Encodes mode properties into the decoder
    */
    func encode(with aCoder: NSCoder)
    {
        if authors != nil{
            aCoder.encode(authors, forKey: "authors")
        }
        if contentVersion != nil{
            aCoder.encode(contentVersion, forKey: "contentVersion")
        }
        if descriptionField != nil{
            aCoder.encode(descriptionField, forKey: "description")
        }
        if imageLinks != nil{
            aCoder.encode(imageLinks, forKey: "imageLinks")
        }
        if language != nil{
            aCoder.encode(language, forKey: "language")
        }
        if printType != nil{
            aCoder.encode(printType, forKey: "printType")
        }
        if publishedDate != nil{
            aCoder.encode(publishedDate, forKey: "publishedDate")
        }
        if publisher != nil{
            aCoder.encode(publisher, forKey: "publisher")
        }
        if title != nil{
            aCoder.encode(title, forKey: "title")
        }

    }

}
